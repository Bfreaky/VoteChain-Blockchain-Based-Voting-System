pragma circom 2.1.0;

include "circomlib/circuits/poseidon.circom";
include "circomlib/circuits/mux1.circom";

// Proves that a leaf belongs to a Poseidon Merkle tree with a given root.
template MerkleProof(depth) {
    signal input leaf;
    signal input pathElements[depth];
    signal input pathIndices[depth];   // 0 = leaf is left child, 1 = leaf is right child
    signal output root;

    component mux[depth];
    component hasher[depth];
    signal levels[depth + 1];
    levels[0] <== leaf;

    for (var i = 0; i < depth; i++) {
        pathIndices[i] * (1 - pathIndices[i]) === 0;   // index must be a bit

        mux[i] = MultiMux1(2);
        mux[i].c[0][0] <== levels[i];
        mux[i].c[0][1] <== pathElements[i];
        mux[i].c[1][0] <== pathElements[i];
        mux[i].c[1][1] <== levels[i];
        mux[i].s <== pathIndices[i];

        hasher[i] = Poseidon(2);
        hasher[i].inputs[0] <== mux[i].out[0];
        hasher[i].inputs[1] <== mux[i].out[1];
        levels[i + 1] <== hasher[i].out;
    }
    root <== levels[depth];
}

// VoteChain circuit.
// Public : root, nullifierHash, electionId, candidateId
// Private: nullifier, secret, Merkle path
// Statement: "I know (nullifier, secret) whose commitment Poseidon(nullifier, secret)
// is a leaf of the voter tree with this root, and nullifierHash = Poseidon(nullifier, electionId)."
template Vote(depth) {
    signal input root;
    signal input nullifierHash;
    signal input electionId;
    signal input candidateId;

    signal input nullifier;
    signal input secret;
    signal input pathElements[depth];
    signal input pathIndices[depth];

    component commitment = Poseidon(2);
    commitment.inputs[0] <== nullifier;
    commitment.inputs[1] <== secret;

    component nullHasher = Poseidon(2);
    nullHasher.inputs[0] <== nullifier;
    nullHasher.inputs[1] <== electionId;
    nullHasher.out === nullifierHash;

    component tree = MerkleProof(depth);
    tree.leaf <== commitment.out;
    for (var i = 0; i < depth; i++) {
        tree.pathElements[i] <== pathElements[i];
        tree.pathIndices[i] <== pathIndices[i];
    }
    tree.root === root;

    // Binds the chosen candidate to the proof so it cannot be swapped by a relayer.
    signal candidateSquare;
    candidateSquare <== candidateId * candidateId;
}

component main { public [root, nullifierHash, electionId, candidateId] } = Vote(10);
