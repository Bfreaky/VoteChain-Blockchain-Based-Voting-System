// Compiles the circuit, runs a local Groth16 trusted setup and exports the Solidity verifier.
// NOTE: the ceremony here is a single-contributor DEV setup. A production election would
// need a multi-party ceremony so that no one knows the toxic waste.
const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const run = (cmd) => { console.log("> " + cmd); execSync(cmd, { cwd: root, stdio: "inherit" }); };
const POWER = 13; // 2^13 = 8192 >= 6235 constraints

fs.mkdirSync(path.join(root, "build"), { recursive: true });
run("npx circom2 circuits/vote.circom --r1cs --wasm --sym -o build -l node_modules");
run(`npx snarkjs powersoftau new bn128 ${POWER} build/pot_0.ptau`);
run(`npx snarkjs powersoftau contribute build/pot_0.ptau build/pot_1.ptau --name="VoteChain dev" -e="${Date.now()}-votechain-group19"`);
run(`npx snarkjs powersoftau prepare phase2 build/pot_1.ptau build/pot_final.ptau`);
run("npx snarkjs groth16 setup build/vote.r1cs build/pot_final.ptau build/vote_0.zkey");
run(`npx snarkjs zkey contribute build/vote_0.zkey build/vote_final.zkey --name="VoteChain dev zkey" -e="${Date.now()}-zkey-group19"`);
run("npx snarkjs zkey export verificationkey build/vote_final.zkey build/verification_key.json");
run("npx snarkjs zkey export solidityverifier build/vote_final.zkey contracts/Groth16Verifier.sol");

// Copy browser artifacts for the frontend
const pub = path.join(root, "frontend", "public", "zk");
fs.mkdirSync(pub, { recursive: true });
fs.copyFileSync(path.join(root, "build/vote_js/vote.wasm"), path.join(pub, "vote.wasm"));
fs.copyFileSync(path.join(root, "build/vote_final.zkey"), path.join(pub, "vote_final.zkey"));
fs.copyFileSync(path.join(root, "build/verification_key.json"), path.join(pub, "verification_key.json"));
console.log("ZK setup complete.");
