// npx hardhat run scripts/deploy.js --network localhost     (or --network amoy)
const hre = require("hardhat");
const fs = require("fs");
const path = require("path");

async function main() {
  const { ethers, network } = hre;
  const [deployer] = await ethers.getSigners();
  console.log("Deploying with:", deployer.address, "on", network.name);

  const verifier = await (await ethers.getContractFactory("Groth16Verifier")).deploy();
  await verifier.waitForDeployment();
  const title = process.env.ELECTION_TITLE || "Ward 7 Local Body Election 2026";
  const election = await (await ethers.getContractFactory("VoteChain")).deploy(title, await verifier.getAddress());
  await election.waitForDeployment();

  const deployBlock = (await election.deploymentTransaction().wait()).blockNumber;
  const chainId = Number((await ethers.provider.getNetwork()).chainId);
  const art = await hre.artifacts.readArtifact("VoteChain");
  const out = {
    network: network.name,
    chainId,
    verifier: await verifier.getAddress(),
    election: await election.getAddress(),
    deployBlock,
    abi: art.abi,
  };
  const file = path.join(__dirname, "../frontend/src/deployment.json");
  fs.writeFileSync(file, JSON.stringify(out, null, 2));
  console.log("Verifier :", out.verifier);
  console.log("Election :", out.election);
  console.log("Saved to frontend/src/deployment.json");
}
main().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
