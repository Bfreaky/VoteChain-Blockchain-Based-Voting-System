// Full election in the terminal (backup demo if the browser/MetaMask fails).
// npx hardhat run scripts/demo-cli.js            (uses the in-process Hardhat network)
const hre = require("hardhat");
const zk = require("../lib/zk");

async function main() {
  const { ethers } = hre;
  const [admin, relayer] = await ethers.getSigners();
  const verifier = await (await ethers.getContractFactory("Groth16Verifier")).deploy();
  const election = await (await ethers.getContractFactory("VoteChain")).deploy("CLI Demo Election", await verifier.getAddress());
  const electionId = await election.electionId();

  console.log("1) Admin adds candidates");
  for (const n of ["Asha Verma", "Rohit Negi", "Meera Joshi"]) await election.addCandidate(n);

  console.log("2) Voters create credentials locally; admin registers only the commitments");
  const creds = [];
  for (let i = 0; i < 5; i++) { const c = await zk.createCredential(); creds.push(c); await election.registerVoter(c.commitment); }
  const tree = await zk.buildTree(creds.map((c) => c.commitment));

  console.log("3) Admin starts voting with Merkle root", tree.root.toString().slice(0, 12) + "...");
  await election.startVoting(tree.root);

  console.log("4) Voters cast anonymous votes (proof generated locally, sent by a relayer)");
  const choices = [0, 1, 0, 2, 0];
  for (let i = 0; i < 5; i++) {
    const p = await zk.generateVoteProof({ credential: creds[i], tree, leafIndex: i, electionId, candidateId: choices[i] });
    await election.connect(relayer).castVote(p.candidateId, p.nullifierHash, p.a, p.b, p.c);
    console.log(`   voter ${i + 1} voted (nullifier ${p.nullifierHash.toString().slice(0, 10)}...)`);
  }

  console.log("5) Double-vote attempt by voter 1");
  try {
    const p = await zk.generateVoteProof({ credential: creds[0], tree, leafIndex: 0, electionId, candidateId: 1 });
    await election.connect(relayer).castVote(p.candidateId, p.nullifierHash, p.a, p.b, p.c);
  } catch (e) { console.log("   rejected:", e.revert ? e.revert.name : e.message.split("\n")[0]); }

  await election.endVoting();
  const names = await election.getCandidates();
  const res = await election.getResults();
  console.log("6) Final tally:");
  names.forEach((n, i) => console.log(`   ${n}: ${res[i]}`));
}
main().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
