// Demo helper (local network): adds candidates, creates demo voter credentials and registers them.
// Voting is NOT started, so you can press "Start voting" in the admin panel during the demo.
// npx hardhat run scripts/seed.js --network localhost
const hre = require("hardhat");
const fs = require("fs");
const path = require("path");
const zk = require("../lib/zk");

async function main() {
  const dep = JSON.parse(fs.readFileSync(path.join(__dirname, "../frontend/src/deployment.json")));
  const election = await hre.ethers.getContractAt("VoteChain", dep.election);
  const candidates = ["Asha Verma", "Rohit Negi", "Meera Joshi"];
  for (const c of candidates) await (await election.addCandidate(c)).wait();

  const demo = [];
  for (let i = 1; i <= 5; i++) {
    const cred = await zk.createCredential();
    await (await election.registerVoter(cred.commitment)).wait();
    demo.push({
      label: `Demo voter ${i}`,
      nullifier: cred.nullifier.toString(),
      secret: cred.secret.toString(),
      commitment: cred.commitment.toString(),
    });
  }
  const file = path.join(__dirname, "../demo-credentials.json");
  fs.writeFileSync(file, JSON.stringify(demo, null, 2));
  console.log(`Added ${candidates.length} candidates and registered ${demo.length} demo voters.`);
  console.log("Demo credentials saved to demo-credentials.json (paste one into the Vote tab).");
}
main().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
