const { expect } = require("chai");
const { ethers } = require("hardhat");
const zk = require("../lib/zk");

describe("VoteChain (Solidity + Polygon-ready, Groth16 ZK proofs)", function () {
  this.timeout(300000);

  let admin, other, relayer, election, verifier;
  let creds, tree, electionId;

  async function deploy() {
    [admin, other, relayer] = await ethers.getSigners();
    verifier = await (await ethers.getContractFactory("Groth16Verifier")).deploy();
    election = await (await ethers.getContractFactory("VoteChain")).deploy("Ward 7 Council Election", await verifier.getAddress());
    electionId = await election.electionId();
  }

  async function setup(n = 3) {
    await election.addCandidate("Asha Verma");
    await election.addCandidate("Rohit Negi");
    creds = [];
    for (let i = 0; i < n; i++) {
      const c = await zk.createCredential();
      creds.push(c);
      await election.registerVoter(c.commitment);
    }
    tree = await zk.buildTree(creds.map((c) => c.commitment));
    await election.startVoting(tree.root);
  }

  const vote = (signer, p) => election.connect(signer).castVote(p.candidateId, p.nullifierHash, p.a, p.b, p.c);

  before(async () => { await zk.init(); });
  beforeEach(deploy);

  it("deploys in Registration phase with the deployer as admin", async () => {
    expect(await election.admin()).to.equal(admin.address);
    expect(await election.phase()).to.equal(0n);
    expect(await election.title()).to.equal("Ward 7 Council Election");
  });

  it("only the admin can add candidates, register voters, start and end", async () => {
    await expect(election.connect(other).addCandidate("X")).to.be.revertedWithCustomError(election, "NotAdmin");
    await expect(election.connect(other).registerVoter(5)).to.be.revertedWithCustomError(election, "NotAdmin");
    await expect(election.connect(other).startVoting(1)).to.be.revertedWithCustomError(election, "NotAdmin");
  });

  it("rejects duplicate and invalid commitments", async () => {
    const c = await zk.createCredential();
    await election.registerVoter(c.commitment);
    await expect(election.registerVoter(c.commitment)).to.be.revertedWithCustomError(election, "AlreadyRegistered");
    await expect(election.registerVoter(0)).to.be.revertedWithCustomError(election, "InvalidCommitment");
  });

  it("needs at least 2 candidates and 1 voter to start", async () => {
    await expect(election.startVoting(1)).to.be.revertedWithCustomError(election, "NotEnoughSetup");
  });

  it("accepts valid anonymous votes and counts them correctly", async () => {
    await setup(3);
    const p0 = await zk.generateVoteProof({ credential: creds[0], tree, leafIndex: 0, electionId, candidateId: 0 });
    const p1 = await zk.generateVoteProof({ credential: creds[1], tree, leafIndex: 1, electionId, candidateId: 1 });
    const p2 = await zk.generateVoteProof({ credential: creds[2], tree, leafIndex: 2, electionId, candidateId: 1 });
    // A relayer submits all three: the sender address is irrelevant to eligibility -> anonymity
    await expect(vote(relayer, p0)).to.emit(election, "VoteCast").withArgs(p0.nullifierHash, 0);
    await vote(relayer, p1);
    await vote(relayer, p2);
    const results = await election.getResults();
    expect(results.map(Number)).to.deep.equal([1, 2]);
    expect(await election.totalVotes()).to.equal(3n);
  });

  it("blocks double voting (same nullifier) even for a different candidate", async () => {
    await setup(2);
    const first = await zk.generateVoteProof({ credential: creds[0], tree, leafIndex: 0, electionId, candidateId: 0 });
    const second = await zk.generateVoteProof({ credential: creds[0], tree, leafIndex: 0, electionId, candidateId: 1 });
    await vote(admin, first);
    await expect(vote(admin, second)).to.be.revertedWithCustomError(election, "NullifierAlreadyUsed");
    expect(Number((await election.getResults())[1])).to.equal(0);
  });

  it("rejects a proof whose candidate was tampered with", async () => {
    await setup(2);
    const p = await zk.generateVoteProof({ credential: creds[0], tree, leafIndex: 0, electionId, candidateId: 0 });
    await expect(election.castVote(1, p.nullifierHash, p.a, p.b, p.c)).to.be.revertedWithCustomError(election, "InvalidProof");
  });

  it("rejects a proof generated for another election id", async () => {
    await setup(2);
    const p = await zk.generateVoteProof({ credential: creds[0], tree, leafIndex: 0, electionId: 12345n, candidateId: 0 });
    await expect(vote(admin, p)).to.be.revertedWithCustomError(election, "InvalidProof");
  });

  it("an unregistered person cannot even generate a valid proof", async () => {
    await setup(2);
    const intruder = await zk.createCredential();
    await expect(
      zk.generateVoteProof({ credential: intruder, tree, leafIndex: 0, electionId, candidateId: 0 })
    ).to.be.rejected;
  });

  it("rejects invalid candidate ids and votes outside the Voting phase", async () => {
    await election.addCandidate("A");
    await election.addCandidate("B");
    const c = await zk.createCredential();
    await election.registerVoter(c.commitment);
    const t = await zk.buildTree([c.commitment]);
    const dummy = [[0, 0], [[0, 0], [0, 0]], [0, 0]];
    await expect(election.castVote(0, 1, ...dummy)).to.be.revertedWithCustomError(election, "WrongPhase");
    await election.startVoting(t.root);
    await expect(election.castVote(9, 1, ...dummy)).to.be.revertedWithCustomError(election, "InvalidCandidate");
    const p = await zk.generateVoteProof({ credential: c, tree: t, leafIndex: 0, electionId, candidateId: 0 });
    await election.endVoting();
    await expect(vote(admin, p)).to.be.revertedWithCustomError(election, "WrongPhase");
  });

  it("lets anyone audit the Merkle root by rebuilding it from public commitments", async () => {
    await setup(4);
    const onchain = (await election.getCommitments()).map(BigInt);
    const rebuilt = await zk.buildTree(onchain);
    expect(rebuilt.root).to.equal(await election.merkleRoot());
  });

  it("emits only nullifiers and candidate ids - no voter identity in vote events", async () => {
    await setup(2);
    const p = await zk.generateVoteProof({ credential: creds[0], tree, leafIndex: 0, electionId, candidateId: 1 });
    const tx = await vote(relayer, p);
    const receipt = await tx.wait();
    const ev = receipt.logs.map((l) => election.interface.parseLog(l)).find((e) => e && e.name === "VoteCast");
    expect(ev.args.length).to.equal(2);              // nullifierHash, candidateId only
    expect(ev.args[0]).to.not.equal(creds[0].commitment);
  });
});
