// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @notice Interface of the snarkjs-generated Groth16 verifier for circuits/vote.circom
interface IVerifier {
    function verifyProof(
        uint[2] calldata _pA,
        uint[2][2] calldata _pB,
        uint[2] calldata _pC,
        uint[4] calldata _pubSignals
    ) external view returns (bool);
}

/// @title VoteChain
/// @notice Tamper-proof, anonymous voting for local elections.
///  - The admin (election authority) registers approved voters' *commitments* only,
///    never their identities or secrets.
///  - Voting needs a zero-knowledge proof of Merkle-tree membership, so the contract learns
///    "an eligible voter voted for candidate X" but not *which* voter.
///  - A per-election nullifier stops double voting without revealing who voted.
contract VoteChain {
    enum Phase { Registration, Voting, Ended }

    uint256 public constant TREE_DEPTH = 10;                       // must match circuit
    uint256 public constant MAX_VOTERS = 2 ** TREE_DEPTH;          // 1024 voters
    uint256 internal constant SNARK_FIELD =
        21888242871839275222246405745257275088548364400416034343698204186575808495617;

    IVerifier public immutable verifier;
    address public immutable admin;
    string public title;
    uint256 public immutable electionId;   // binds proofs to this election + chain

    Phase public phase;
    uint256 public merkleRoot;
    uint256 public totalVotes;

    string[] private candidateNames;
    uint256[] private tally;
    uint256[] private commitments;
    mapping(uint256 => bool) public isRegistered;      // commitment => registered
    mapping(uint256 => bool) public nullifierUsed;     // nullifierHash => used

    event CandidateAdded(uint256 indexed id, string name);
    event VoterRegistered(uint256 indexed index, uint256 commitment);
    event VotingStarted(uint256 merkleRoot, uint256 voters);
    event VoteCast(uint256 indexed nullifierHash, uint256 indexed candidateId);
    event VotingEnded(uint256 totalVotes);

    error NotAdmin();
    error WrongPhase();
    error InvalidCandidate();
    error AlreadyRegistered();
    error ElectionFull();
    error NullifierAlreadyUsed();
    error InvalidProof();
    error NotEnoughSetup();
    error InvalidCommitment();

    modifier onlyAdmin() {
        if (msg.sender != admin) revert NotAdmin();
        _;
    }

    modifier inPhase(Phase p) {
        if (phase != p) revert WrongPhase();
        _;
    }

    constructor(string memory _title, address _verifier) {
        title = _title;
        verifier = IVerifier(_verifier);
        admin = msg.sender;
        electionId = uint256(keccak256(abi.encodePacked(address(this), block.chainid))) % SNARK_FIELD;
    }

    // ---------------------------------------------------------------- setup
    function addCandidate(string calldata name) external onlyAdmin inPhase(Phase.Registration) {
        candidateNames.push(name);
        tally.push(0);
        emit CandidateAdded(candidateNames.length - 1, name);
    }

    /// @param commitment Poseidon(nullifier, secret) produced by the voter in the browser.
    function registerVoter(uint256 commitment) external onlyAdmin inPhase(Phase.Registration) {
        if (commitment == 0 || commitment >= SNARK_FIELD) revert InvalidCommitment();
        if (isRegistered[commitment]) revert AlreadyRegistered();
        if (commitments.length >= MAX_VOTERS) revert ElectionFull();
        isRegistered[commitment] = true;
        commitments.push(commitment);
        emit VoterRegistered(commitments.length - 1, commitment);
    }

    /// @param root Merkle root of all registered commitments. Anyone can recompute it from
    ///        the VoterRegistered events to audit the admin (the frontend does this).
    function startVoting(uint256 root) external onlyAdmin inPhase(Phase.Registration) {
        if (candidateNames.length < 2 || commitments.length < 1) revert NotEnoughSetup();
        merkleRoot = root;
        phase = Phase.Voting;
        emit VotingStarted(root, commitments.length);
    }

    // --------------------------------------------------------------- voting
    function castVote(
        uint256 candidateId,
        uint256 nullifierHash,
        uint[2] calldata a,
        uint[2][2] calldata b,
        uint[2] calldata c
    ) external inPhase(Phase.Voting) {
        if (candidateId >= candidateNames.length) revert InvalidCandidate();
        if (nullifierUsed[nullifierHash]) revert NullifierAlreadyUsed();

        // public signals order = order declared in circuit main(): root, nullifierHash, electionId, candidateId
        uint[4] memory pub = [merkleRoot, nullifierHash, electionId, candidateId];
        if (!verifier.verifyProof(a, b, c, pub)) revert InvalidProof();

        nullifierUsed[nullifierHash] = true;
        tally[candidateId] += 1;
        totalVotes += 1;
        emit VoteCast(nullifierHash, candidateId);
    }

    function endVoting() external onlyAdmin inPhase(Phase.Voting) {
        phase = Phase.Ended;
        emit VotingEnded(totalVotes);
    }

    // ----------------------------------------------------------------- views
    function candidateCount() external view returns (uint256) { return candidateNames.length; }
    function commitmentCount() external view returns (uint256) { return commitments.length; }
    function getCandidates() external view returns (string[] memory) { return candidateNames; }
    function getResults() external view returns (uint256[] memory) { return tally; }
    function getCommitments() external view returns (uint256[] memory) { return commitments; }
}
