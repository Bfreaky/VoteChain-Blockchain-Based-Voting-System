import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { nodePolyfills } from "vite-plugin-node-polyfills";

// circomlibjs / snarkjs / web3 expect a few Node globals (Buffer, process, events, assert).
export default defineConfig({
  plugins: [react(), nodePolyfills({ globals: { Buffer: true, global: true, process: true } })],
  build: { target: "es2020", chunkSizeWarningLimit: 6000 },
  optimizeDeps: { esbuildOptions: { target: "es2020" } },
});
