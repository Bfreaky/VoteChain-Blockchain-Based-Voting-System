import React, { useCallback, useEffect, useState } from "react";
import { connectWallet, getContract, readState, readVoteEvents, isDeployed, explorerBase, deploymentInfo } from "./chain.js";
import { initZk, createCredential, buildTree, generateVoteProof } from "./zk.js";

const PHASES = ["Registration", "Voting", "Results"];
const LS_KEY = "votechain-credential";
const short = (v, n = 10) => { const s = v.toString(); return s.length > n * 2 ? s.slice(0, n) + "..." + s.slice(-6) : s; };
const FRIENDLY = {
  NullifierAlreadyUsed: "This voter credential has already been used to vote in this election.",
  InvalidProof: "The zero-knowledge proof was rejected by the verifier contract.",
  NotAdmin: "Only the election admin wallet can do this.",
  WrongPhase: "This action is not allowed in the current election phase.",
  AlreadyRegistered: "This commitment is already registered.",
  NotEnoughSetup: "Add at least 2 candidates and 1 voter before starting.",
  InvalidCandidate: "That candidate does not exist.",
  InvalidCommitment: "That commitment value is not valid.",
  ElectionFull: "The voter list is full (1024 voters).",
};
const errText = (e) => {
  const raw = (e?.cause?.message || e?.data?.message || e?.message || String(e)).split("\n")[0];
  const hit = Object.keys(FRIENDLY).find((k) => raw.includes(k));
  return hit ? FRIENDLY[hit] : raw;
};

function download(name, text) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type: "application/json" }));
  a.download = name; a.click(); URL.revokeObjectURL(a.href);
}

export default function App() {
  const [wallet, setWallet] = useState(null);
  const [contract, setContract] = useState(null);
  const [st, setSt] = useState(null);
  const [events, setEvents] = useState([]);
  const [tab, setTab] = useState("vote");
  const [note, setNote] = useState(null);        // {kind, text}
  const [busy, setBusy] = useState(false);
  const [cred, setCred] = useState(() => { try { return JSON.parse(localStorage.getItem(LS_KEY)); } catch { return null; } });
  const [credText, setCredText] = useState("");
  const [pick, setPick] = useState(null);
  const [progress, setProgress] = useState("");
  const [auditMsg, setAuditMsg] = useState(null);
  const [newCand, setNewCand] = useState("");
  const [regText, setRegText] = useState("");

  const refresh = useCallback(async (c = contract) => {
    if (!c) return;
    try { setSt(await readState(c)); setEvents(await readVoteEvents(c)); } catch (e) { setNote({ kind: "bad", text: errText(e) }); }
  }, [contract]);

  useEffect(() => { initZk(); }, []);
  useEffect(() => { if (!contract) return; const t = setInterval(() => refresh(), 8000); return () => clearInterval(t); }, [contract, refresh]);

  async function connect() {
    try {
      const w = await connectWallet();
      const c = getContract(w.web3);
      setWallet(w); setContract(c); setNote(null);
      await refresh(c);
    } catch (e) { setNote({ kind: "bad", text: errText(e) }); }
  }

  async function run(label, fn) {
    setBusy(true); setNote({ kind: "info", text: label + "..." });
    try { await fn(); setNote({ kind: "ok", text: label + " - done." }); await refresh(); }
    catch (e) { setNote({ kind: "bad", text: errText(e) }); }
    finally { setBusy(false); setProgress(""); }
  }

  const isAdmin = wallet && st && wallet.account.toLowerCase() === st.admin.toLowerCase();
  const send = (m) => m.send({ from: wallet.account });

  // ------------------------------------------------------------ voter actions
  async function makeCredential() {
    const c = await createCredential();
    localStorage.setItem(LS_KEY, JSON.stringify(c));
    setCred(c);
    setNote({ kind: "ok", text: "Credential created in this browser. Download a backup and send only the commitment to the election office." });
  }
  function loadCredential() {
    try {
      const c = JSON.parse(credText);
      if (!c.nullifier || !c.secret || !c.commitment) throw new Error("Missing fields");
      localStorage.setItem(LS_KEY, JSON.stringify(c)); setCred(c); setCredText("");
      setNote({ kind: "ok", text: "Credential loaded." });
    } catch { setNote({ kind: "bad", text: "That is not a valid credential JSON." }); }
  }

  async function castVote() {
    await run("Casting anonymous vote", async () => {
      const index = st.commitments.findIndex((c) => c === BigInt(cred.commitment));
      if (index < 0) throw new Error("Your commitment is not in the registered voter list. Ask the election office to register it.");
      setProgress("Building voter Merkle tree in your browser...");
      const tree = await buildTree(st.commitments);
      if (tree.root !== st.merkleRoot) throw new Error("Local Merkle root does not match the on-chain root. The voter list may have been tampered with.");
      setProgress("Generating zero-knowledge proof (takes a few seconds)...");
      const p = await generateVoteProof({ credential: cred, tree, leafIndex: index, electionId: st.electionId, candidateId: pick });
      setProgress("Waiting for wallet signature and block confirmation...");
      await send(contract.methods.castVote(p.candidateId, p.nullifierHash, p.a, p.b, p.c));
    });
  }

  // ------------------------------------------------------------ admin actions
  const addCandidate = () => run("Adding candidate", async () => { await send(contract.methods.addCandidate(newCand.trim())); setNewCand(""); });
  const registerVoters = () => run("Registering voters", async () => {
    const list = regText.split(/[\s,]+/).filter(Boolean);
    for (const c of list) await send(contract.methods.registerVoter(c));
    setRegText("");
  });
  const startVoting = () => run("Starting voting", async () => {
    const tree = await buildTree(st.commitments);
    await send(contract.methods.startVoting(tree.root.toString()));
  });
  const endVoting = () => run("Ending voting", async () => { await send(contract.methods.endVoting()); });

  // ------------------------------------------------------------ audit
  async function auditRoot() {
    const tree = await buildTree(st.commitments);
    if (st.phase === 0) return setAuditMsg({ kind: "info", text: "Voting has not started, so there is no published root yet." });
    setAuditMsg(tree.root === st.merkleRoot
      ? { kind: "ok", text: "Verified: the Merkle root on-chain equals the root rebuilt from the public voter commitments." }
      : { kind: "bad", text: "MISMATCH: the on-chain root does not match the registered voter commitments." });
  }

  // ------------------------------------------------------------ render
  const base = explorerBase();
  const total = st ? st.candidates.reduce((s, c) => s + c.votes, 0) : 0;

  return (
    <div className="wrap">
      <header className="top">
        <div className="brand">Vote<span>Chain</span></div>
        <div className="row">
          {wallet && <span className="chip">{wallet.account.slice(0, 6)}...{wallet.account.slice(-4)}{isAdmin ? " (admin)" : ""}</span>}
          <span className="chip">{deploymentInfo.network} / chain {deploymentInfo.chainId}</span>
        </div>
      </header>

      {!isDeployed() && <div className="msg warn">No contract deployed yet. Run <b>npm run deploy:local</b> (or deploy:amoy) from the project root, then restart this app.</div>}

      {!wallet && (
        <div className="card">
          <h2>Anonymous, verifiable local elections</h2>
          <p className="muted">Votes are recorded on Polygon through a Solidity smart contract. A zero-knowledge proof shows you are an eligible voter who has not voted yet, without revealing who you are.</p>
          <button className="btn" onClick={connect} disabled={!isDeployed()}>Connect wallet</button>
        </div>
      )}
      {note && <div className={"msg " + note.kind} role="status">{note.text}</div>}

      {wallet && st && (
        <>
          <h2>{st.title}</h2>
          <div className="steps">
            {PHASES.map((p, i) => <div key={p} className={"step " + (st.phase === i ? "on" : st.phase > i ? "done" : "")}>{i + 1}. {p}</div>)}
          </div>
          <div className="tabs" role="tablist">
            {[["vote", "Vote"], ["results", "Results and audit"], ["admin", "Election office"]].map(([k, l]) =>
              <button key={k} role="tab" aria-selected={tab === k} className={"tab " + (tab === k ? "on" : "")} onClick={() => setTab(k)}>{l}</button>)}
          </div>

          {tab === "vote" && (
            <>
              <div className="card">
                <h3>Your voter credential</h3>
                <p className="muted">Your credential is created and kept in this browser. The election office only ever sees the commitment, never the secret.</p>
                {cred ? (
                  <>
                    <p className="muted">Commitment (send this to the election office):</p>
                    <div className="mono">{cred.commitment}</div>
                    <div className="row" style={{ marginTop: 10 }}>
                      <button className="btn ghost" onClick={() => navigator.clipboard.writeText(cred.commitment)}>Copy commitment</button>
                      <button className="btn ghost" onClick={() => download("votechain-credential.json", JSON.stringify(cred, null, 2))}>Download backup</button>
                    </div>
                    <p className="muted">Status: {st.commitments.some((c) => c === BigInt(cred.commitment)) ? "registered as an eligible voter" : "not registered yet"}</p>
                  </>
                ) : (
                  <button className="btn" onClick={makeCredential}>Create my credential</button>
                )}
                <details style={{ marginTop: 12 }}>
                  <summary className="muted">Load an existing credential</summary>
                  <textarea value={credText} onChange={(e) => setCredText(e.target.value)} placeholder='{"nullifier":"...","secret":"...","commitment":"..."}' />
                  <button className="btn ghost" onClick={loadCredential} style={{ marginTop: 8 }}>Load</button>
                </details>
              </div>

              <div className="card">
                <h3>Cast your vote</h3>
                {st.phase !== 1 && <div className="msg info">{st.phase === 0 ? "Voting has not started yet." : "Voting has ended. See the results tab."}</div>}
                {st.candidates.map((c) => (
                  <label key={c.id} className={"cand " + (pick === c.id ? "sel" : "")}>
                    <input type="radio" name="cand" checked={pick === c.id} onChange={() => setPick(c.id)} disabled={st.phase !== 1} /> <b>{c.name}</b>
                  </label>
                ))}
                <button className="btn" disabled={busy || st.phase !== 1 || pick === null || !cred} onClick={castVote}>Generate proof and vote</button>
                {progress && <div className="msg info">{progress}</div>}
                <p className="muted" style={{ marginTop: 12 }}>Privacy note: the contract never uses your wallet address to decide eligibility, but the sender address of a transaction is public on any blockchain. For strongest anonymity vote from a fresh wallet or through a relayer.</p>
              </div>
            </>
          )}

          {tab === "results" && (
            <>
              <div className="card">
                <div className="stats">
                  <div className="stat"><b>{st.commitments.length}</b>registered voters</div>
                  <div className="stat"><b>{total}</b>votes counted</div>
                  <div className="stat"><b>{st.commitments.length ? Math.round((total / st.commitments.length) * 100) : 0}%</b>turnout</div>
                </div>
              </div>
              <div className="card">
                <h3>Tally</h3>
                {st.candidates.map((c) => (
                  <div key={c.id} style={{ marginBottom: 12 }}>
                    <div className="row" style={{ justifyContent: "space-between" }}><b>{c.name}</b><span>{c.votes}</span></div>
                    <div className="bar"><i style={{ width: (total ? (c.votes / total) * 100 : 0) + "%" }} /></div>
                  </div>
                ))}
              </div>
              <div className="card">
                <h3>Public audit</h3>
                <p className="muted">Anyone can check the election without trusting the election office.</p>
                <button className="btn" onClick={auditRoot}>Verify voter-list Merkle root</button>
                {auditMsg && <div className={"msg " + auditMsg.kind}>{auditMsg.text}</div>}
                <p className="muted">Election contract: <span className="mono">{deploymentInfo.election}</span> {base && <a href={`${base}/address/${deploymentInfo.election}`} target="_blank" rel="noreferrer">view on Polygonscan</a>}</p>
                <p className="muted">Verifier contract: <span className="mono">{deploymentInfo.verifier}</span></p>
                <h3 style={{ marginTop: 14 }}>Recorded votes (anonymous)</h3>
                <table>
                  <thead><tr><th>Block</th><th>Nullifier</th><th>Candidate</th></tr></thead>
                  <tbody>
                    {events.map((e) => <tr key={e.tx}><td>{e.block}</td><td className="mono">{short(e.nullifier, 8)}</td><td>{st.candidates[e.candidateId]?.name}</td></tr>)}
                    {events.length === 0 && <tr><td colSpan={3} className="muted">No votes yet.</td></tr>}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {tab === "admin" && (
            <div className="card">
              <h3>Election office</h3>
              {!isAdmin && <div className="msg warn">Connect with the admin wallet ({short(st.admin, 6)}) to use these actions. Contract rules enforce this on-chain.</div>}
              <p className="muted">Phase: {PHASES[st.phase]}</p>

              <h3 style={{ marginTop: 14 }}>1. Add candidates</h3>
              <div className="row">
                <input className="grow" type="text" value={newCand} onChange={(e) => setNewCand(e.target.value)} placeholder="Candidate name" />
                <button className="btn" disabled={busy || !isAdmin || st.phase !== 0 || !newCand.trim()} onClick={addCandidate}>Add</button>
              </div>
              <p className="muted">{st.candidates.map((c) => c.name).join(", ") || "No candidates yet."}</p>

              <h3 style={{ marginTop: 14 }}>2. Register eligible voters (commitments only)</h3>
              <p className="muted">Verify each voter's identity offline, then paste the commitment they send you (one per line).</p>
              <textarea value={regText} onChange={(e) => setRegText(e.target.value)} placeholder="commitment 1&#10;commitment 2" />
              <button className="btn" style={{ marginTop: 8 }} disabled={busy || !isAdmin || st.phase !== 0 || !regText.trim()} onClick={registerVoters}>Register voters</button>

              <h3 style={{ marginTop: 14 }}>3. Start and end</h3>
              <div className="row">
                <button className="btn" disabled={busy || !isAdmin || st.phase !== 0} onClick={startVoting}>Start voting</button>
                <button className="btn ghost" disabled={busy || !isAdmin || st.phase !== 1} onClick={endVoting}>End voting</button>
              </div>
              <p className="muted">Starting computes the voter Merkle root from the public commitments and publishes it. Registration closes at that moment.</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
