// Browser-side zero-knowledge helpers. Same logic as lib/zk.js (Node).
// Secrets are generated and used ONLY in the browser; they are never sent anywhere.
import { buildPoseidon } from "circomlibjs";
import * as snarkjs from "snarkjs";

export const DEPTH = 10; // must match circuits/vote.circom
const WASM = "/zk/vote.wasm";
const ZKEY = "/zk/vote_final.zkey";

let poseidon, F;
export async function initZk() {
  if (!poseidon) { poseidon = await buildPoseidon(); F = poseidon.F; }
}
export const hash2 = (a, b) => F.toObject(poseidon([BigInt(a), BigInt(b)]));

export function randomField() {
  const bytes = crypto.getRandomValues(new Uint8Array(31)); // 248 bits < field prime
  return BigInt("0x" + [...bytes].map((b) => b.toString(16).padStart(2, "0")).join(""));
}

export async function createCredential() {
  await initZk();
  const nullifier = randomField();
  const secret = randomField();
  return { nullifier: nullifier.toString(), secret: secret.toString(), commitment: hash2(nullifier, secret).toString() };
}

export async function buildTree(leaves, depth = DEPTH) {
  await initZk();
  const zeros = [0n];
  for (let i = 0; i < depth; i++) zeros.push(hash2(zeros[i], zeros[i]));
  const layers = [leaves.map(BigInt)];
  for (let lvl = 0; lvl < depth; lvl++) {
    const cur = layers[lvl];
    const next = [];
    for (let i = 0; i < cur.length; i += 2) next.push(hash2(cur[i], i + 1 < cur.length ? cur[i + 1] : zeros[lvl]));
    if (next.length === 0) next.push(zeros[lvl + 1]);
    layers.push(next);
  }
  const root = layers[depth][0];
  const getPath = (index) => {
    const pathElements = [], pathIndices = [];
    let idx = index;
    for (let lvl = 0; lvl < depth; lvl++) {
      const sib = idx ^ 1;
      pathElements.push(sib < layers[lvl].length ? layers[lvl][sib] : zeros[lvl]);
      pathIndices.push(idx & 1);
      idx >>= 1;
    }
    return { pathElements, pathIndices };
  };
  return { root, getPath };
}

export async function generateVoteProof({ credential, tree, leafIndex, electionId, candidateId }) {
  await initZk();
  const { pathElements, pathIndices } = tree.getPath(leafIndex);
  const nullifierHash = hash2(credential.nullifier, electionId);
  const input = {
    root: tree.root.toString(),
    nullifierHash: nullifierHash.toString(),
    electionId: BigInt(electionId).toString(),
    candidateId: String(candidateId),
    nullifier: credential.nullifier,
    secret: credential.secret,
    pathElements: pathElements.map(String),
    pathIndices: pathIndices.map(String),
  };
  const { proof } = await snarkjs.groth16.fullProve(input, WASM, ZKEY);
  return {
    candidateId: String(candidateId),
    nullifierHash: nullifierHash.toString(),
    a: [proof.pi_a[0], proof.pi_a[1]],
    b: [[proof.pi_b[0][1], proof.pi_b[0][0]], [proof.pi_b[1][1], proof.pi_b[1][0]]],
    c: [proof.pi_c[0], proof.pi_c[1]],
  };
}
