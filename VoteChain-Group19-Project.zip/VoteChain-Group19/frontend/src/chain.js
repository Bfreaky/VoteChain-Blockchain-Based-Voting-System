// Web3.js bridge between the React app and the VoteChain smart contract.
import Web3 from "web3";
import deployment from "./deployment.json";

export const NETWORKS = {
  31337: { chainId: "0x7a69", chainName: "Hardhat Local", rpcUrls: ["http://127.0.0.1:8545"], nativeCurrency: { name: "ETH", symbol: "ETH", decimals: 18 } },
  80002: { chainId: "0x13882", chainName: "Polygon Amoy Testnet", rpcUrls: ["https://rpc-amoy.polygon.technology"], nativeCurrency: { name: "POL", symbol: "POL", decimals: 18 }, blockExplorerUrls: ["https://amoy.polygonscan.com"] },
};

export const isDeployed = () => Boolean(deployment.election);
export const explorerBase = () => (deployment.chainId === 80002 ? "https://amoy.polygonscan.com" : null);

export async function connectWallet() {
  if (!window.ethereum) throw new Error("No wallet found. Install MetaMask.");
  const web3 = new Web3(window.ethereum);
  const accounts = await web3.eth.requestAccounts();
  const want = deployment.chainId;
  const have = Number(await web3.eth.getChainId());
  if (have !== want) {
    const net = NETWORKS[want];
    try {
      await window.ethereum.request({ method: "wallet_switchEthereumChain", params: [{ chainId: net.chainId }] });
    } catch (err) {
      if (err.code === 4902 || err.code === -32603) {
        await window.ethereum.request({ method: "wallet_addEthereumChain", params: [net] });
      } else throw err;
    }
  }
  return { web3, account: accounts[0] };
}

export const getContract = (web3) => new web3.eth.Contract(deployment.abi, deployment.election);

export async function readState(contract) {
  const [title, phase, admin, merkleRoot, totalVotes, electionId, names, results, commitments] = await Promise.all([
    contract.methods.title().call(),
    contract.methods.phase().call(),
    contract.methods.admin().call(),
    contract.methods.merkleRoot().call(),
    contract.methods.totalVotes().call(),
    contract.methods.electionId().call(),
    contract.methods.getCandidates().call(),
    contract.methods.getResults().call(),
    contract.methods.getCommitments().call(),
  ]);
  return {
    title, admin, electionId,
    phase: Number(phase),
    merkleRoot: BigInt(merkleRoot),
    totalVotes: Number(totalVotes),
    candidates: names.map((n, i) => ({ id: i, name: n, votes: Number(results[i]) })),
    commitments: commitments.map((c) => BigInt(c)),
  };
}

export async function readVoteEvents(contract) {
  const evs = await contract.getPastEvents("VoteCast", { fromBlock: deployment.deployBlock || 0, toBlock: "latest" });
  return evs.map((e) => ({ nullifier: BigInt(e.returnValues.nullifierHash), candidateId: Number(e.returnValues.candidateId), block: Number(e.blockNumber), tx: e.transactionHash }));
}

export const deploymentInfo = deployment;
